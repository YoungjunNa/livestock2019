library(maps)  
library(mapdata)
library(ggplot2)
coast_map <- fortify(map("worldHires", fill=TRUE, plot=FALSE))

gg <- ggplot()
gg <- gg + geom_map(data=coast_map, map=coast_map,
                    aes(x=long, y=lat, map_id=region),
                    fill="white", color="black")
gg <- gg + geom_map(data=data.frame(region="South Korea"), map=coast_map,
                    aes(map_id=region), fill="steelblue")
gg <- gg + geom_map(data=data.frame(region="Denmark"), map=coast_map,
                    aes(map_id=region), fill="green")
gg <- gg + geom_map(data=data.frame(region="Japan"), map=coast_map,
                    aes(map_id=region), fill="red")
gg <- gg + geom_map(data=data.frame(region="Australia"), map=coast_map,
                    aes(map_id=region), fill="brown")
gg <- gg + geom_map(data=data.frame(region="USA"), map=coast_map,
                    aes(map_id=region), fill="yellow")
gg <- gg + geom_map(data=data.frame(region="Netherland"), map=coast_map,
                    aes(map_id=region), fill="orange")


gg

