future_price <- read_excel("C:/Users/user/Desktop/future_price.xlsx")

df5 <-future_price %>%
  ggplot(aes(x=year, y=price_future, color=exporter))+
  geom_point() +
  geom_line()+
  geom_text(aes(label = price_future), vjust = -1.2)+
  labs(title = "향후 유럽쇠고기 가격 대응", 
       subtitle="price:(원/kg)", caption = "19년도 가격을 기준으로 예측") +
  theme_economist()

df5
