price <- read_excel("C:/Users/user/Desktop/price.xlsx")

df2 <- price %>%
  ggplot(aes(x=year, y=price, color=원산지))+
  geom_line() +
  geom_point() +
  geom_text(aes(label = price), vjust = -1.2)+
  labs(title = "미국산, 호주산 쇠고기 및 한우의 연도별 도매가", 
       subtitle="price:(원/kg)", caption = "한국농촌경제연구원(2010-2018)") +
  theme_economist()

df2