beefself <- read_excel("C:/Users/user/Desktop/beefself.xlsx")
beefself %>%
 ggplot(aes(year, self.sufficiency)) + geom_smooth(color='red') + 
  labs(title = "한국 쇠고기 자급률" ,
       subtitle = "한우, 육우", caption="한국농촌경제연구원, 쇠고기 자급률 동향과 전망, (2016. 5. 3.)") + 
theme_calc()