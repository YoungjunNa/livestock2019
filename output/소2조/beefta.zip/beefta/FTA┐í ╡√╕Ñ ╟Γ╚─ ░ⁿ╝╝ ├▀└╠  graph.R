tariff <- read_excel("C:/Users/user/Desktop/tariff.xlsx")

df10 <- tariff %>%
  ggplot(aes(x=year, y=tariff, color=exporter))+
  geom_line() +
  geom_point() +
  geom_text(aes(label = tariff), vjust = -1.2)+
  labs(title = "유럽 쇠고기 관세 대응", 
       subtitle="관세 : tariff(%)", caption = "관세청") +
  theme_economist()

df10