library(ggplot2)
library(ggthemes)
library(tidyverse)
library(readxl)

df <- readxl::read_excel("소고기 자급률.xlsx")

df %>%
  ggplot(aes(year, self.sufficiency)) + geom_smooth() + 
  labs(title = "쇠고기 자급률" , subtitle = "한국농촌경제연구원 - 쇠고기 자급률 동향과 전망(2016. 5. 3.)") + 
  theme_calc()
  