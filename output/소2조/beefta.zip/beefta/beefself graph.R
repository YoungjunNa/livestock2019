beef_in <- read_excel("C:/Users/user/Desktop/beef-in.xlsx")

df <- beef_in %>%
  ggplot(aes(x=year, y=import, color=exporter))+
  geom_line() +
  geom_point() +
  geom_text(aes(label = import), vjust = -1.2)+
  labs(title = "미국산, 호주산 쇠고기 국내 수입량", 
       subtitle="2010-2018", caption = "농림축산부") +
  theme_economist()

df